#ifndef _APPS_H_
#define _APPS_H_

// THIS IS ONLY HERE FOR DOXYGEN STRUCTURE

///@defgroup apps Apps

///@dir apps Apps @ingroup apps

///@file apps/apps.h Apps comments. @ingroup apps

#endif