#include "primitive.h"

///@file igl/primitive.cpp Primitives. @ingroup igl

mat4f transformed_matrix(TransformedSurface* transformed, float time) {
    auto m = identity_mat4f;
    
    m = frame_to_matrix_inverse(transformed->pivot) * m;
    
    m = scaling_matrix(transformed->scale) * m;
    
    m = rotation_matrix(transformed->rotation_euler.x,x3f) * m;
    m = rotation_matrix(transformed->rotation_euler.y,y3f) * m;
    m = rotation_matrix(transformed->rotation_euler.z,z3f) * m;
    
    m = translation_matrix(transformed->translation) * m;

    m = frame_to_matrix(transformed->pivot) * m;

    return m;
}

mat4f transformed_matrix_inv(TransformedSurface* transformed, float time) {
    auto mi = identity_mat4f;
    
    mi = mi * frame_to_matrix_inverse(transformed->pivot);
    
    mi = mi * scaling_matrix(1/transformed->scale);
    
    mi = mi * rotation_matrix(-transformed->rotation_euler.x,x3f);
    mi = mi * rotation_matrix(-transformed->rotation_euler.y,y3f);
    mi = mi * rotation_matrix(-transformed->rotation_euler.z,z3f);
    
    mi = mi * translation_matrix(-transformed->translation);
    
    mi = mi * frame_to_matrix(transformed->pivot);
    
    return mi;
}
