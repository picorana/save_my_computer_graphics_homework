#include "scene.h"

///@file igl/scene.cpp Scene. @ingroup igl
