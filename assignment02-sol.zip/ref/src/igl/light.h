#ifndef _LIGHT_H_
#define _LIGHT_H_

#include "node.h"
#include "shape.h"

///@file igl/light.h Lights. @ingroup igl
///@defgroup light Lights
///@ingroup igl
///@{

/// Abstract Light
struct Light : Node {
    frame3f             frame = identity_frame3f; ///< frame
};

/// Point Light at the origin
struct PointLight : Light {
    vec3f               intensity = one3f; ///< intensity
};

/// Directional Light along z
struct DirectionalLight : Light {
    vec3f               intensity = one3f; ///< intensity
};

/// Group of Lights
struct LightGroup : Node {
    vector<Light*>      lights;
};

///@name frame manipulation
/// orients a light
inline void light_lookat(Light* light, const vec3f& eye, const vec3f& center, const vec3f& up) {
    light->frame.o = eye;
    light->frame.z = normalize(center-eye);
    light->frame.y = up;
    light->frame = orthonormalize(light->frame);
}
///@}

///@}

#endif
