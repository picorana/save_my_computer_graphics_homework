#include "camera.h"

///@file igl/camera.cpp Cameras. @ingroup igl
