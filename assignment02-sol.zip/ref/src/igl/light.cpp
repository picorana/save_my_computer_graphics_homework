#include "light.h"

///@file igl/light.cpp Lights. @ingroup igl
