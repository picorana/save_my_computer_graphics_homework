# save_my_computer_graphics_homework
temporary repository for computer graphics homework  
assignment: http://pellacini.di.uniroma1.it/teaching/graphics16/assignments/01_raytrace/notes.html  
framework from: http://pellacini.di.uniroma1.it/teaching/graphics16/index.html
