../bin/raytrace 01_sphere.json
../bin/raytrace 02_quad.json
../bin/raytrace 03_plane.json
../bin/raytrace 04_balls.json
../bin/raytrace 05_refl.json
../bin/raytrace 06_aa.json
